{{/*
=============================================================================
PARENT CHART HELPERS
=============================================================================

HELM CONCEPT - one global template namespace:
  Every {{ define }} in the parent AND in every subchart is registered in a
  SINGLE flat namespace. If two charts both defined "common.labels", the last
  one loaded silently wins and you get baffling output. The universal convention
  - and the reason every name below starts with "aiops-platform." - is to prefix
  template names with the chart name.

HELM CONCEPT - define / include / template:
  {{ define }}  declares a named template.
  {{ include }} calls it and returns a STRING, so it can be piped
                (| nindent, | sha256sum, | quote ...).
  {{ template }} also calls it but returns nothing pipeable. Prefer include.
*/}}

{{/*
Chart name and version as used by the helm.sh/chart label.
`replace "+" "_"` because SemVer build metadata (1.0.0+abc) contains a "+",
which is not a legal character in a Kubernetes label value.
`trunc 63` because label values are capped at 63 characters.
*/}}
{{- define "aiops-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
The recommended Kubernetes label set (kubernetes.io/docs/concepts/overview/working-with-objects/common-labels).
Using the standard keys - rather than a homegrown `app:` - means kubectl,
dashboards and service meshes can group these objects without configuration.
*/}}
{{- define "aiops-platform.labels" -}}
helm.sh/chart: {{ include "aiops-platform.chart" . }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aiops-platform
{{- end -}}

{{/*
=============================================================================
APPLICATION SUBCHART HELPERS
=============================================================================
Every name is prefixed "application." because Helm keeps ALL named templates
from the parent and every subchart in one flat global namespace.
*/}}

{{/* ---------------------------------------------------------------------------
NAMESPACE RESOLUTION - the heart of "parent owns namespaces, subchart does not"
------------------------------------------------------------------------------
The subchart never creates a Namespace, but every object it renders still has to
say which namespace it belongs to. Three sources, in priority order:

  1. .Values.global.namespaces.application  - set by the parent umbrella chart
  2. .Values.namespaceOverride              - set by an operator installing this
                                              subchart on its own
  3. .Release.Namespace                     - the `-n` flag; the natural default

`coalesce` returns the first non-empty argument, which expresses that priority
in one line.

`dig` is used for the global lookup because .Values.global does not exist at all
when the chart is installed standalone. Writing .Values.global.namespaces.application
would then panic with "nil pointer evaluating interface {}.namespaces".
`(.Values.global | default dict)` guards the nil, `dig` walks the rest safely.
--------------------------------------------------------------------------- */}}
{{- define "application.namespace" -}}
{{- $fromParent := dig "namespaces" "application" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.namespaceOverride .Release.Namespace -}}
{{- end -}}

{{/*
Where the monitoring stack lives. Only used by the NetworkPolicy, to allow
Prometheus to scrape these pods. Same three-source resolution, with a literal
fallback so the chart still renders standalone.
*/}}
{{- define "application.monitoringNamespace" -}}
{{- $fromParent := dig "namespaces" "monitoring" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.networkPolicy.monitoringNamespace "monitoring" -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
NAMING

Most public charts name objects "<release>-<chart>". This chart deliberately
uses STABLE names ("url-shortener", "url-shortener-redis") instead, because
these Service DNS names are a published contract consumed from outside the
chart: the Prometheus scrape config, the alert rules and the README's
port-forward commands all reference them. Release-prefixed names would change
those every time someone renames the release.

The trade-off - you cannot install two copies into one namespace - is fine for
a platform component, and fullnameOverride is still there as an escape hatch.

trunc 63 / trimSuffix "-" : names are RFC1123 labels, max 63 chars, and may not
end in a hyphen (which truncation could otherwise produce).
--------------------------------------------------------------------------- */}}
{{- define "application.name" -}}
{{- default "url-shortener" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "application.fullname" -}}
{{- default (include "application.name" .) .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "application.redis.fullname" -}}
{{- printf "%s-redis" (include "application.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Chart name + version for the helm.sh/chart label. */}}
{{- define "application.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
LABELS

selectorLabels = the immutable identity subset. A Deployment's
spec.selector.matchLabels CANNOT be changed after creation, so it must only ever
contain labels that never change. Chart version and appVersion DO change on
every upgrade, which is exactly why they live in `labels` and not in
`selectorLabels`. Mixing them up produces the classic
"field is immutable" error on the second upgrade.

Each manifest adds its own app.kubernetes.io/component (api / redis) on top.
--------------------------------------------------------------------------- */}}
{{- define "application.selectorLabels" -}}
app.kubernetes.io/name: {{ include "application.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "application.labels" -}}
helm.sh/chart: {{ include "application.chart" . }}
{{ include "application.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aiops-platform
{{- end -}}

{{/* ---------------------------------------------------------------------------
IMAGE REFERENCE

Called with a SCOPED context rather than the root one:
    {{ include "application.image" .Values.app.image }}
so inside the template `.` is the image map itself. This is how you write small
reusable helpers without passing the whole chart context around.
--------------------------------------------------------------------------- */}}
{{- define "application.image" -}}
{{- printf "%s:%s" .repository (.tag | default "latest") -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
POD HARDENING

Both blocks together satisfy the Kubernetes "restricted" Pod Security Standard.

runAsUser is set explicitly even though both Dockerfiles already end with a
`USER app` line. Reason: those Dockerfiles create the user with `useradd
--system`, so the image records a user NAME, not a UID. kubelet cannot verify a
name against runAsNonRoot and refuses to start the container with
"container has runAsNonRoot and image has non-numeric user". A numeric UID is
the fix. Any UID works here because the app only reads world-readable files.
--------------------------------------------------------------------------- */}}
{{- define "application.podSecurityContext" -}}
runAsNonRoot: true
runAsUser: 1000
runAsGroup: 1000
fsGroup: 1000
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "application.containerSecurityContext" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop:
    - ALL
{{- end -}}

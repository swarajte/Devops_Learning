{{/*
=============================================================================
AIAGENT SUBCHART HELPERS
=============================================================================
*/}}

{{/* Namespace resolution - identical pattern to the other two subcharts:
     parent global -> local override -> release namespace. */}}
{{- define "aiagent.namespace" -}}
{{- $fromParent := dig "namespaces" "aiagent" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.namespaceOverride .Release.Namespace -}}
{{- end -}}

{{/* Where Prometheus lives, so the agent can query it across namespaces. */}}
{{- define "aiagent.monitoringNamespace" -}}
{{- $fromParent := dig "namespaces" "monitoring" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.monitoringNamespace "monitoring" -}}
{{- end -}}

{{/*
The Prometheus URL the collector queries.
An explicit config.prometheusUrl wins; otherwise it is derived from the shared
namespace map, so the agent and the monitoring chart cannot disagree about where
Prometheus is.
*/}}
{{- define "aiagent.prometheusUrl" -}}
{{- if .Values.config.prometheusUrl -}}
{{- .Values.config.prometheusUrl -}}
{{- else -}}
{{- printf "http://prometheus.%s.svc.cluster.local:9090" (include "aiagent.monitoringNamespace" .) -}}
{{- end -}}
{{- end -}}

{{/*
Stable name: Alertmanager's webhook URL is built from it in the monitoring
chart, so it is a cross-chart contract rather than an internal detail.
*/}}
{{- define "aiagent.fullname" -}}
{{- default "incident-agent" .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Name of the Secret holding LLM_API_KEY and SMTP_PASSWORD.

HELM CONCEPT - `required` and `fail`.
  `required "msg" value` aborts rendering with a readable message when the value
  is empty. This catches a misconfiguration at `helm install` time instead of
  producing a pod that sits in CreateContainerConfigError with no explanation.
  (`fail "msg"` is the unconditional version, used inside an if/else.)
*/}}
{{- define "aiagent.secretName" -}}
{{- if .Values.secret.create -}}
{{- printf "%s-secrets" (include "aiagent.fullname" .) -}}
{{- else -}}
{{- required "aiagent.secret.name is required when secret.create=false - it must name a Secret you created out-of-band containing LLM_API_KEY and SMTP_PASSWORD" .Values.secret.name -}}
{{- end -}}
{{- end -}}

{{- define "aiagent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "aiagent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "aiagent.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "aiagent.labels" -}}
helm.sh/chart: {{ include "aiagent.chart" . }}
{{ include "aiagent.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aiops-platform
{{- end -}}

{{- define "aiagent.image" -}}
{{- printf "%s:%s" .repository (.tag | default "latest") -}}
{{- end -}}

{{/*
Same numeric-UID reasoning as the application chart: the agent's Dockerfile ends
with `USER agent`, a name kubelet cannot check against runAsNonRoot.
*/}}
{{- define "aiagent.podSecurityContext" -}}
runAsNonRoot: true
runAsUser: 1000
runAsGroup: 1000
fsGroup: 1000
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "aiagent.containerSecurityContext" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop:
    - ALL
{{- end -}}

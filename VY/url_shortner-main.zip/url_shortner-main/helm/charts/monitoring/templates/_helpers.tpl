{{/*
=============================================================================
MONITORING SUBCHART HELPERS
=============================================================================
*/}}

{{/* ---------------------------------------------------------------------------
NAMESPACES

Three lookups, all with the same shape: value from the parent's `global` map if
present, then a local override, then a sensible literal. `dig` + `default dict`
keeps this safe when the chart is installed standalone and .Values.global does
not exist at all.

The cross-namespace ones matter because this chart has to build DNS names for
things it does not own:
  - applicationNamespace -> used by the Kubernetes-level alert rules
  - aiagentNamespace     -> used to build Alertmanager's webhook URL
--------------------------------------------------------------------------- */}}
{{- define "monitoring.namespace" -}}
{{- $fromParent := dig "namespaces" "monitoring" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.namespaceOverride .Release.Namespace -}}
{{- end -}}

{{- define "monitoring.applicationNamespace" -}}
{{- $fromParent := dig "namespaces" "application" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.alerting.appNamespace "url-shortener" -}}
{{- end -}}

{{- define "monitoring.aiagentNamespace" -}}
{{- $fromParent := dig "namespaces" "aiagent" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.alertmanager.aiagentNamespace "ai-agent" -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
COMPONENT NAMES

Stable, unprefixed names again - `prometheus.monitoring.svc` is quoted in the
agent's config, in the README and in every port-forward command, so it is a
contract rather than an implementation detail.
--------------------------------------------------------------------------- */}}
{{- define "monitoring.prometheus.fullname" -}}prometheus{{- end -}}
{{- define "monitoring.alertmanager.fullname" -}}alertmanager{{- end -}}
{{- define "monitoring.kubeStateMetrics.fullname" -}}kube-state-metrics{{- end -}}

{{/*
Fully-qualified in-cluster addresses, built once and reused by the Prometheus
config, the Alertmanager config and the NOTES. Using the FQDN (…svc.cluster.local)
rather than the short name avoids relying on the pod's search-domain list, which
differs between distributions.
*/}}
{{- define "monitoring.prometheus.address" -}}
{{- printf "%s.%s.svc.cluster.local:9090" (include "monitoring.prometheus.fullname" .) (include "monitoring.namespace" .) -}}
{{- end -}}

{{- define "monitoring.alertmanager.address" -}}
{{- printf "%s.%s.svc.cluster.local:9093" (include "monitoring.alertmanager.fullname" .) (include "monitoring.namespace" .) -}}
{{- end -}}

{{- define "monitoring.kubeStateMetrics.address" -}}
{{- printf "%s.%s.svc.cluster.local:8080" (include "monitoring.kubeStateMetrics.fullname" .) (include "monitoring.namespace" .) -}}
{{- end -}}

{{/*
Where Alertmanager delivers fired alerts.

An explicit alertmanager.webhookUrl always wins (point it at Slack, PagerDuty,
or the debug receiver). Otherwise the incident agent's cross-namespace address
is derived from global.namespaces.aiagent, so the two charts stay wired together
without either one hardcoding the other's namespace.
*/}}
{{- define "monitoring.alertmanager.webhookUrl" -}}
{{- if .Values.alertmanager.webhookUrl -}}
{{- .Values.alertmanager.webhookUrl -}}
{{- else -}}
{{- printf "http://incident-agent.%s.svc.cluster.local:8080/alert" (include "monitoring.aiagentNamespace" .) -}}
{{- end -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
CLUSTER-SCOPED RBAC NAMES

ClusterRoles and ClusterRoleBindings are NOT namespaced, so a plain name like
"prometheus" collides the moment this chart is installed twice (staging + prod
in one cluster). The install of the second release fails with an ownership
error, or worse, silently rebinds the first one's permissions.
Prefixing with the namespace makes them unique.
--------------------------------------------------------------------------- */}}
{{- define "monitoring.clusterRoleName" -}}
{{- printf "%s-%s" (include "monitoring.namespace" .ctx) .component | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
LABELS - called with a dict, not the root context

    {{ include "monitoring.labels" (dict "ctx" . "component" "prometheus") }}

HELM CONCEPT - passing a scoped context.
  A named template can only see the single value passed to it. `dict` builds a
  map on the fly so one helper can serve three different components. Inside the
  template, `.ctx` is the original root context and `.component` is the extra
  argument.

Why app.kubernetes.io/name differs per component here (and not in the
application subchart): Prometheus, Alertmanager and kube-state-metrics are three
separate upstream applications that happen to be packaged together, so each gets
its own "name". In the application chart the app and its Redis are one logical
application, distinguished only by "component".
--------------------------------------------------------------------------- */}}
{{- define "monitoring.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "monitoring.selectorLabels" -}}
app.kubernetes.io/name: {{ .component }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
{{- end -}}

{{- define "monitoring.labels" -}}
helm.sh/chart: {{ include "monitoring.chart" .ctx }}
{{ include "monitoring.selectorLabels" . }}
app.kubernetes.io/component: {{ .component }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
app.kubernetes.io/part-of: aiops-platform
{{- end -}}

{{/* Image reference; called with the image map as its context. */}}
{{- define "monitoring.image" -}}
{{- printf "%s:%s" .repository (.tag | default "latest") -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------
POD HARDENING

65534 = "nobody". The prometheus, alertmanager and kube-state-metrics images all
already run as that UID, so pinning it changes nothing at runtime but lets
kubelet verify runAsNonRoot and satisfies the "restricted" Pod Security Standard.

fsGroup matters here in a way it did not for the app: Prometheus WRITES its TSDB
to a mounted volume. Without fsGroup the volume is owned by root and Prometheus
crashes on startup with "permission denied" on /prometheus.
--------------------------------------------------------------------------- */}}
{{- define "monitoring.podSecurityContext" -}}
runAsNonRoot: true
runAsUser: 65534
runAsGroup: 65534
fsGroup: 65534
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "monitoring.containerSecurityContext" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop:
    - ALL
{{- end -}}

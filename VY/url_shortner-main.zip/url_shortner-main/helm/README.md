# AIOps Platform — Helm charts

Helm packaging for the URL shortener, its monitoring stack, and the AI incident
agent. Replaces the raw manifests in `k8s/`.

Tested against **Helm 3.21.x** and **Kubernetes 1.36** (`kubeVersion: ">=1.25.0-0"`).

> **New to this chart?** Read **[HELM_GUIDE.md](HELM_GUIDE.md)** first — it walks
> through how the raw manifests were converted, every Helm concept used and
> where to read it, the versioning rules, and the reasoning behind each design
> decision. This README is the operational reference.

---

## 1. Layout

```
helm/
├── Chart.yaml               # umbrella chart: composes the three subcharts
├── values.yaml              # laptop/demo defaults
├── values-prod.yaml         # production overlay (differences only)
├── values.schema.json       # validates global.namespaces + toggles
├── templates/
│   ├── _helpers.tpl
│   ├── namespaces.yaml      # the ONLY resource the parent creates
│   └── NOTES.txt
└── charts/
    ├── application/         # url-shortener + redis
    ├── monitoring/          # prometheus + alertmanager + kube-state-metrics
    └── aiagent/             # incident-agent + read-only RBAC
```

Three namespaces, one release:

| Namespace       | Chart         | Contents                                        |
|-----------------|---------------|-------------------------------------------------|
| `url-shortener` | `application` | FastAPI app (×2), Redis, ConfigMap              |
| `monitoring`    | `monitoring`  | Prometheus, Alertmanager, kube-state-metrics    |
| `ai-agent`      | `aiagent`     | incident-agent, read-only ClusterRole           |

---

## 2. Install

The umbrella chart installs into its own **control namespace**, and creates the
three workload namespaces itself:

```bash
helm upgrade --install aiops ./helm \
  -n aiops-platform --create-namespace
```

> **Why a separate control namespace?** Helm stores its release Secret in the
> namespace you pass to `-n`, so that namespace must already exist before
> install. If you point `-n` at `url-shortener` *and* the chart also declares a
> `url-shortener` Namespace, the install fails with *"cannot be imported into
> the current release"*. `templates/namespaces.yaml` skips
> `.Release.Namespace` defensively, but a dedicated control namespace keeps all
> three workload namespaces Helm-managed, which is what you want.

Then create the agent's credentials (the chart deliberately does not own them —
see §6) and roll the agent:

```bash
kubectl create secret generic incident-agent-secrets -n ai-agent \
  --from-literal=LLM_API_KEY='<your-llm-token>' \
  --from-literal=SMTP_PASSWORD=''

kubectl rollout restart deploy/incident-agent -n ai-agent
```

Production:

```bash
helm upgrade --install aiops ./helm -n aiops-platform --create-namespace \
  -f ./helm/values-prod.yaml \
  --set application.app.image.tag="$GIT_SHA" \
  --set aiagent.image.tag="$GIT_SHA" \
  --atomic --timeout 10m
```

`--atomic` rolls the whole release back if anything fails to become ready, so
you never end up half-upgraded.

### Installing a subchart on its own

Every subchart is independently installable — it creates no namespace and has no
dependency on the parent:

```bash
helm install app  ./helm/charts/application -n url-shortener --create-namespace
helm install mon  ./helm/charts/monitoring  -n monitoring    --create-namespace
helm install agent ./helm/charts/aiagent    -n ai-agent      --create-namespace
```

Standalone, each chart falls back to `.Release.Namespace` and to literal
defaults for the namespaces it does not own (see `*.namespace` helpers). Install
via the umbrella chart and `global.namespaces` takes over.

### Turning components off

```bash
helm upgrade aiops ./helm -n aiops-platform --set aiagent.enabled=false
helm upgrade aiops ./helm -n aiops-platform \
  --set monitoring.enabled=false --set aiagent.enabled=false
```

The dependencies also declare `tags: [workload]` / `[observability]`, but note
the precedence rule: Helm applies tags first and then conditions, and a
condition whose path exists in `values.yaml` overrides the tag. Since
`monitoring.enabled` and `aiagent.enabled` are both defined, `--set
tags.observability=false` on its own is silently ignored. The `enabled` flags
are the authoritative switches — `templates/namespaces.yaml` reads the same
flags to decide which namespaces to create.

---

## 3. Verify

```bash
helm lint ./helm --strict
helm template aiops ./helm | kubectl apply --dry-run=server -f -   # server-side validation
helm test aiops -n aiops-platform
helm get manifest aiops -n aiops-platform     # exactly what is in the cluster
helm diff upgrade aiops ./helm                # requires the helm-diff plugin
```

`helm test` runs a Pod per subchart that proves something real: the application
test hits `/readyz` (which pings Redis) and creates a short code; the monitoring
test asserts Prometheus loaded the alert rules and has live scrape targets.

---

## 4. Design decisions

### Parent owns namespaces, subcharts do not

A namespace outlives any single component and is shared by several. If each
subchart created its own, two of them could never share a namespace (both would
claim ownership), and uninstalling one would delete a namespace another still
uses. One owner removes the whole class of problem.

Subcharts still have to *place* their objects, so every one of them resolves its
namespace through a helper:

```
global.namespaces.<chart>   →   .Values.namespaceOverride   →   .Release.Namespace
```

`coalesce` picks the first non-empty; `dig` guards the `global` lookup, which
does not exist at all when the chart is installed standalone.

Helm's kind-based install ordering puts `Namespace` first, so no hooks are
needed to sequence this.

### Stable object names instead of `<release>-<chart>`

Most charts prefix names with the release. These do not, because the Service DNS
names are a **published contract** between the charts: Alertmanager's webhook
URL points at `incident-agent.ai-agent.svc`, the agent queries
`prometheus.monitoring.svc`, and the app's `REDIS_HOST` resolves to the Redis
Service. Release-prefixing would make those depend on what someone typed after
`helm install`. `fullnameOverride` remains available.

Cost: you cannot install two copies into one namespace. That is the right
trade-off for a platform component, and it is why the cluster-scoped RBAC names
*are* namespace-prefixed — those genuinely do collide across installs.

### Values that exist, and values that do not

Included: image tags, replica counts, resources, persistence, namespaces,
feature toggles, everything in the agent's config.

Deliberately **not** parameterised: probe paths and thresholds, container ports,
Prometheus scrape/evaluation intervals, alert thresholds, the `prometheus.io/*`
annotations. Those describe how this specific software behaves. Exposing them
would add knobs nobody turns, and each one is a line of documentation, a schema
entry and a test case forever.

The single best example of templating done right is `REDIS_HOST`: it is derived
from the same helper that names the Redis Service, so the two cannot drift.
Templating earns its keep by removing duplicated facts, not by adding knobs.

### Redis stays a Deployment

A StatefulSet buys stable per-replica identity, ordered rollout and per-replica
volumes. This is a single-replica store with no clustering, so it uses none of
them. Switch when it becomes Sentinel/Cluster — or better, use managed Redis.

### Hand-rolled monitoring, not `kube-prometheus-stack`

In production you would depend on the community chart and get the Prometheus
Operator, CRDs and Grafana. Here the mechanics — service discovery, relabelling,
rule evaluation, alert routing — *are* the subject, and the operator hides them
behind CRDs. See the comment at the top of `charts/monitoring/Chart.yaml`.

---

## 5. Improvements over the raw `k8s/` manifests

| Change | Why |
|---|---|
| `startupProbe` on the app | Slow starts no longer force a long `initialDelaySeconds` on the liveness probe, so real hangs are still caught in ~30s |
| `maxUnavailable: 0` rolling update | Genuinely zero-downtime deploys |
| PodDisruptionBudget | Node drains and cluster upgrades cannot take the service to zero |
| `checksum/config` pod annotations | A config-only `helm upgrade` actually restarts the pods — previously Prometheus silently kept its old scrape config |
| Explicit relabels instead of blanket `labelmap` | The old config copied `pod-template-hash` onto every series, so **every deploy doubled cardinality** |
| Hardened `securityContext` everywhere | Non-root with a **numeric** UID, all capabilities dropped, read-only root filesystem, `seccompProfile: RuntimeDefault` — satisfies the `restricted` Pod Security Standard |
| Pod Security Admission labels on namespaces | Enforced at `baseline`, audited at `restricted` — the standard safe rollout path |
| `automountServiceAccountToken: false` on app and Redis | Neither calls the Kubernetes API; the mounted token was a credential sitting in a web server for no reason |
| Namespace-prefixed ClusterRole names | Unprefixed cluster-scoped names collide the moment the chart is installed twice |
| `--cluster.listen-address=` on Alertmanager | Stops single-replica gossip errors and the startup settle delay |
| `--save ""` on Redis without a PVC | Stops endless snapshot-write failures against a read-only filesystem |
| `terminationGracePeriodSeconds: 120` on the agent | A ~90s LLM call is no longer SIGKILLed mid-analysis during a rollout |
| Optional PVCs, HPA, Ingress, NetworkPolicy | Off by default, one flag away |
| No CPU limits (requests only) | CPU is compressible; a limit only adds throttling latency. Memory *is* limited because it is not |

### Note on the numeric UID

Both Dockerfiles end with `USER app` / `USER agent`, created via `useradd
--system` — so the image records a user **name**, not a UID. kubelet cannot
verify a name against `runAsNonRoot: true` and refuses to start the container
with *"image has non-numeric user"*. Setting `runAsUser: 1000` explicitly is the
fix; the processes only read world-readable files, so the UID is free to choose.

---

## 6. Secrets

The chart manages the **shape** of the agent's Secret (its name, and which keys
the Deployment expects) but not its **contents**. `secret.create` defaults to
`false`.

Putting the LLM token in a values file would copy it into git, into
`helm get values`, and into Helm's release Secret — where it survives every
rollback and shows up in `helm history`. Three unrotated copies.

This is also the seam for External Secrets Operator or the Vault agent injector:
they populate a Secret with the same name and nothing else in the chart changes.

The cost is honest: Helm cannot hash a Secret it does not own, so rotating the
key needs an explicit `kubectl rollout restart`.

`secret.create=true` exists for laptop clusters and warns you in `NOTES.txt`.

---

## 7. Helm concepts used, and where to read them

| Concept | Where |
|---|---|
| Umbrella chart + vendored subcharts | `Chart.yaml` |
| `condition` and `tags` | `Chart.yaml` dependencies |
| `global` values | `values.yaml`, every `*.namespace` helper |
| `define` / `include` / template-name collisions | all `_helpers.tpl` |
| Scoped context via `dict` | `charts/monitoring/templates/_helpers.tpl` |
| Template variables (`$roleName`) | `charts/aiagent/templates/rbac.yaml` |
| `coalesce`, `dig`, `default`, `required` | namespace + secret-name helpers |
| `tpl` — rendering a value as a template | `charts/monitoring/templates/prometheus/configmap.yaml` |
| `.Files.Get` and `.Files.Glob` | same file, plus `charts/monitoring/files/` |
| Escaping `{{ }}` for Prometheus | `charts/monitoring/files/alert-rules/app-alerts.yaml` |
| `toYaml \| nindent` (and why not `indent`) | every `resources:` block |
| Config checksums that force a rollout | app / Prometheus / Alertmanager / agent Deployments |
| Hooks, weights, delete policies | `templates/tests/*` |
| `NOTES.txt` and `--render-subchart-notes` | every chart |
| `values.schema.json` | parent and `charts/application` |
| `helm.sh/resource-policy: keep` | PVCs, optional on namespaces |
| Conditional whole objects (`if`) | HPA, Ingress, PDB, NetworkPolicy, Secret |
| `range` over a map | `templates/namespaces.yaml`, rules ConfigMap |
| Layered `-f` files and merge semantics | `values-prod.yaml` |

Deliberately avoided: the `lookup` function (returns empty during
`helm template` and `--dry-run`, so any template that branches on it renders
differently than it applies), and `.Capabilities.APIVersions` gymnastics
(`kubeVersion` in `Chart.yaml` states the requirement once instead).

---

## 8. Operating notes

**Uninstall.** `helm uninstall aiops -n aiops-platform` deletes the namespaces
and everything in them — including the out-of-band agent Secret. Set
`namespaces.retain=true` to keep them (as `values-prod.yaml` does).

**Re-installing over a retained namespace** fails with an ownership error.
Adopt it instead of deleting it:

```bash
kubectl annotate ns url-shortener \
  meta.helm.sh/release-name=aiops meta.helm.sh/release-namespace=aiops-platform --overwrite
kubectl label ns url-shortener app.kubernetes.io/managed-by=Helm --overwrite
```

**Rollback.** `helm rollback aiops -n aiops-platform` — only meaningful with
immutable image tags. With `latest`, the manifest rolls back and the running
image does not.

**Trigger a demo incident.**

```bash
kubectl scale deploy/url-shortener-redis -n url-shortener --replicas=0
# RedisDown fires after 1m -> Alertmanager -> agent -> RCA email
kubectl scale deploy/url-shortener-redis -n url-shortener --replicas=1
```

**Common failures.**

| Symptom | Cause |
|---|---|
| Agent pod `CreateContainerConfigError` | `incident-agent-secrets` does not exist yet |
| Prometheus scrapes nothing | app pods missing `prometheus.io/scrape` annotations, or the pod-discovery relabel `keep` dropped them — check `/api/v1/targets` |
| Alerts fire but nothing arrives | Alertmanager webhook URL points at the wrong namespace — check `helm get manifest \| grep webhook` |
| `helm upgrade` says "field is immutable" | A label was moved into `selectorLabels`; Deployment selectors cannot change |

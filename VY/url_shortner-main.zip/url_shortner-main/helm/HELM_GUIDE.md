# Helm Guide — from raw manifests to a production chart

A walkthrough of how the `k8s/` manifests in this repo became the chart in
`helm/`: the Helm concepts involved, why each design decision was made, how to
operate it, and — the question that trips most people up — **which version
number to change when**.

Written to be read top to bottom by someone who has used `kubectl` but not much
Helm. Every concept is tied to a real file in this repo, so you can read the
explanation and the code side by side.

**Target environment**

| Tool | Version |
|---|---|
| Helm | v3.21.3 (go1.26.5) |
| kubectl | v1.36.3 |
| Kubernetes API server | v1.36.1 |
| Kustomize (bundled in kubectl) | v5.8.1 |
| Local cluster | minikube |

---

## Contents

1. [What Helm actually is](#1-what-helm-actually-is)
2. [What we started with, and what was wrong with it](#2-what-we-started-with-and-what-was-wrong-with-it)
3. [The architecture we built](#3-the-architecture-we-built)
4. [Chart anatomy — every file and what it does](#4-chart-anatomy--every-file-and-what-it-does)
5. [How the templating works](#5-how-the-templating-works)
6. [Every Helm concept used, with the file to read](#6-every-helm-concept-used-with-the-file-to-read)
7. [Template function cheat sheet](#7-template-function-cheat-sheet)
8. [Versioning — which number to change when](#8-versioning--which-number-to-change-when)
9. [How to use it day to day](#9-how-to-use-it-day-to-day)
10. [Our cluster — how the pieces find each other](#10-our-cluster--how-the-pieces-find-each-other)
11. [Improvements made over the raw manifests](#11-improvements-made-over-the-raw-manifests)
12. [Mistakes made while building this](#12-mistakes-made-while-building-this)
13. [Troubleshooting](#13-troubleshooting)
14. [Interview talking points](#14-interview-talking-points)

---

## 1. What Helm actually is

Three ideas, and everything else follows from them.

**A chart is a package.** A directory with metadata (`Chart.yaml`), default
configuration (`values.yaml`) and Go templates (`templates/`). It is inert until
installed.

**A release is an installed instance of a chart.** `helm install aiops ./helm`
creates a release named `aiops`. Helm renders the templates against the values,
applies the result, and stores the *whole rendered manifest plus the values* in
a Secret in the release namespace. That stored copy is what makes
`helm rollback`, `helm history` and `helm diff` possible — Helm is not
reading it back from the cluster, it kept a copy.

**Rendering is just text substitution, then YAML.** Helm has no idea what a
Deployment is. It produces a string, splits it on `---`, parses each chunk as
YAML and sends it to the API server. Almost every confusing Helm error is really
a YAML indentation error caused by the template that produced it. Keep that
model in your head and Helm stops being mysterious.

What Helm gives you that `kubectl apply -f k8s/` does not:

- **One command, one unit.** Install, upgrade, roll back or delete the whole
  platform atomically, instead of remembering an apply order.
- **Environment differences without file copies.** Same templates, different
  values. No `k8s-dev/` and `k8s-prod/` directories drifting apart.
- **Real deletion.** `helm uninstall` removes exactly what it created.
  `kubectl apply -f` has no equivalent — deleting a manifest from the folder
  leaves the object running in the cluster forever.
- **History and rollback.** `helm rollback aiops 3` restores revision 3's
  manifests exactly.
- **Derived values.** The app's `REDIS_HOST` is computed from the same helper
  that names the Redis Service, so they cannot disagree. This is the single
  biggest maintainability win and it has nothing to do with configurability.

---

## 2. What we started with, and what was wrong with it

The original `k8s/` folder — still in the repo for reference — is 14 YAML files
across three folders, applied in a documented order:

```
k8s/namespace.yaml, configmap.yaml, redis.yaml, app-deployment.yaml, app-service.yaml
k8s/monitoring/00-namespace.yaml … 08-alert-receiver.yaml
k8s/agent/00-namespace.yaml … 04-deployment.yaml
```

They work. The problems are the ones that only show up over time:

| Problem | Consequence |
|---|---|
| `REDIS_HOST: "redis"` written in the ConfigMap, `name: redis` written in the Service | Two places to change, one silent outage when you change only one |
| Namespace names hardcoded in ~10 files | Renaming `monitoring` means a grep-and-pray |
| The number-prefix apply order is documentation, not a mechanism | Nothing enforces it |
| A ConfigMap edit does not restart the pods reading it | `kubectl apply` "succeeds" and Prometheus keeps its old scrape config — a *monitoring system* silently monitoring the wrong thing |
| No way to run dev and prod from the same source | Copy the folder, edit, drift |
| No uninstall, no rollback, no history | Cleanup is manual and error-prone |
| Everything runs as root with a writable root filesystem | Fails any serious security review |

The conversion kept every working behaviour and fixed the structural issues.
Nothing about how the app, Prometheus or the agent behave at runtime was changed
except where it was a bug (see §11).

---

## 3. The architecture we built

### Parent (umbrella) chart + three subcharts

```
helm/                         ← parent chart "aiops-platform"
├── Chart.yaml                    declares the three subcharts as dependencies
├── values.yaml                   global.namespaces + on/off switches
├── values-prod.yaml              production overlay (differences only)
├── values.schema.json            validates the namespace map before rendering
├── templates/
│   ├── namespaces.yaml           ← the ONLY resource the parent creates
│   ├── _helpers.tpl
│   └── NOTES.txt
└── charts/
    ├── application/          ← url-shortener + Redis      → ns url-shortener
    ├── monitoring/           ← Prometheus stack           → ns monitoring
    └── aiagent/              ← incident agent + RBAC      → ns ai-agent
```

**Why an umbrella chart rather than three separate ones?** Because the three
components are wired to each other. Alertmanager posts to the agent; the agent
queries Prometheus; Prometheus's alert rules filter on the app's namespace.
Those cross-references need one source of truth, which is `global.namespaces` in
the parent. Three unrelated releases would mean repeating the same namespace
names in three values files.

**Why not one flat chart?** Because you would lose the ability to install,
upgrade or reason about one component in isolation, and a single `templates/`
directory with 25 files and no boundaries becomes unnavigable.

### The parent owns namespace creation

This was an explicit requirement, and it is also the right call:

- A namespace has a **longer lifecycle** than any component inside it.
- If two subcharts both declared the same Namespace, the second install fails
  with *"already exists"* / *"cannot be imported into the current release"* —
  Helm refuses to let two releases own one object.
- `helm uninstall monitoring` would delete a namespace that `application` is
  still living in.

One owner removes the whole category of problem.

`templates/namespaces.yaml` iterates the namespace map and creates one Namespace
per **enabled** subchart:

```yaml
{{- range $key, $name := .Values.global.namespaces }}
{{- $subchart := index $.Values $key | default dict }}
{{- if $subchart.enabled }}
```

`index $.Values $key` is a dynamic lookup — `$key` is `"application"` /
`"monitoring"` / `"aiagent"`, so this reads `.Values.application.enabled` and so
on. Go templates have no `.Values.$key` syntax; `index` is how you do it.

**No hook is needed to make namespaces come first.** Helm does not apply
manifests in file order — it sorts by *kind*, using a fixed install order in
which `Namespace` is first, then RBAC, ConfigMaps, Secrets, Services, and
workloads last. Deletion uses the reverse order.

### Subcharts create no namespaces, and are independently installable

Each subchart still has to *place* its objects somewhere, so every one resolves
its namespace through the same helper:

```
global.namespaces.<chart>  →  .Values.namespaceOverride  →  .Release.Namespace
```

```gotemplate
{{- define "application.namespace" -}}
{{- $fromParent := dig "namespaces" "application" "" (.Values.global | default dict) -}}
{{- coalesce $fromParent .Values.namespaceOverride .Release.Namespace -}}
{{- end -}}
```

Two functions doing specific jobs:

- `coalesce` returns the first **non-empty** argument, which expresses the
  priority order in one line.
- `dig` walks a nested map with a fallback. It is here because
  `.Values.global` **does not exist at all** when the subchart is installed on
  its own — and `.Values.global.namespaces.application` on a nil map panics with
  `nil pointer evaluating interface {}.namespaces`. `(.Values.global | default
  dict)` guards the nil and `dig` walks the rest safely.

So all of these work:

```bash
helm install aiops ./helm -n aiops-platform --create-namespace   # global wins
helm install app ./helm/charts/application -n url-shortener --create-namespace
helm install app ./helm/charts/application -n whatever --set namespaceOverride=url-shortener
```

---

## 4. Chart anatomy — every file and what it does

### Files Helm treats specially

| File | Meaning |
|---|---|
| `Chart.yaml` | Metadata. Required. `apiVersion: v2` = Helm 3 format |
| `values.yaml` | Default configuration |
| `values.schema.json` | JSON Schema; validated **before** any template renders |
| `templates/*.yaml` | Rendered and sent to the cluster |
| `templates/_helpers.tpl` | Leading `_` = **not** rendered as a manifest; holds `define` blocks |
| `templates/NOTES.txt` | Rendered and **printed to the terminal**, not applied |
| `templates/tests/*` | Convention only — what makes them tests is the `helm.sh/hook: test` annotation |
| `files/**` | **Not** rendered. Readable from templates via `.Files` |
| `charts/**` | Subcharts, loaded automatically |
| `.helmignore` | Excluded from `helm package`, same syntax as `.gitignore` |

### `Chart.yaml` fields worth understanding

```yaml
apiVersion: v2            # Helm 3. Lets dependencies live here (v1 used requirements.yaml)
name: aiops-platform
type: application         # vs "library" — a library chart provides templates but cannot be installed
version: 1.0.0            # version of THE CHART. SemVer, enforced. See §8
appVersion: "1.0.0"       # version of THE SOFTWARE. Free-form. Becomes app.kubernetes.io/version
kubeVersion: ">=1.25.0-0" # refuses to install on an older cluster
```

The `-0` suffix in `kubeVersion` is not decoration. SemVer ranges exclude
pre-releases by default, so plain `">=1.25.0"` would **reject** a cluster
reporting `v1.25.0-eks-abc123`. `-0` makes the range include pre-release
versions.

### Dependencies

```yaml
dependencies:
  - name: application
    version: "1.0.0"
    condition: application.enabled
    tags: [workload]
```

The three subcharts physically live in `charts/`, so Helm loads them
automatically and `repository:` is omitted — there is nothing to download.
Listing them anyway is what unlocks `condition` and `tags`.

> **We deliberately did not use `repository: file://charts/application`.** That
> form is for charts you build with `helm dependency update`, which replaces the
> readable directories with opaque `.tgz` files. For a repo people are meant to
> *read*, keeping the source browsable in git is worth more.

**The `condition` vs `tags` precedence rule** catches almost everyone: Helm
applies **tags first, then conditions**, and a condition whose path *exists* in
values overrides whatever the tag decided. Because `values.yaml` defines
`monitoring.enabled` and `aiagent.enabled`, those conditions always resolve —
so `--set tags.observability=false` on its own is **silently ignored** here.
The `enabled` flags are the authoritative switches. The tags are declared to
demonstrate the mechanism and to group the charts semantically.

---

## 5. How the templating works

### Context: `.`, `$`, and scope

`.` is the current context. At the top of a template it is the root object:

| Path | What it is |
|---|---|
| `.Values` | merged values (defaults ← `-f` files ← `--set`) |
| `.Release.Name` / `.Release.Namespace` / `.Release.Service` | release info; `.Service` is always `"Helm"` |
| `.Chart.Name` / `.Chart.Version` / `.Chart.AppVersion` | from `Chart.yaml` |
| `.Capabilities.KubeVersion` | the live cluster's version |
| `.Files` | non-template files in the chart |
| `.Template.BasePath` | this chart's `templates/` directory, as a template name |

Inside `range` and `with`, **`.` is rebound** to the current element. `$` always
means the original root, which is why `templates/namespaces.yaml` writes
`$.Values` inside its loop.

### Named templates and the global namespace trap

`define` declares a named template; `include` calls it and returns a **string**,
so it can be piped:

```gotemplate
{{- include "application.labels" . | nindent 4 }}
```

`template` also calls it but returns nothing pipeable — **always prefer
`include`**.

> **The trap:** every `define` in the parent *and* every subchart is registered
> in **one flat global namespace**. If two charts both defined `common.labels`,
> the last one loaded silently wins and you get baffling output. That is why
> every helper in this repo is prefixed with its chart name:
> `application.labels`, `monitoring.labels`, `aiagent.labels`.

### Passing a scoped context with `dict`

A named template can only see the single value you pass it. `charts/monitoring`
serves three different components from one helper by building a map on the fly:

```gotemplate
{{- include "monitoring.labels" (dict "ctx" . "component" "prometheus") | nindent 4 }}
```

Inside, `.ctx` is the root context and `.component` is the extra argument.

`charts/application` uses the simpler style — a fixed `app.kubernetes.io/name`
with `component` added inline per manifest. That difference is intentional:
the app and its Redis are **one** logical application with two components,
whereas Prometheus, Alertmanager and kube-state-metrics are **three separate
upstream applications** that happen to be packaged together, so each deserves
its own `name`.

### `nindent`, and the single most common Helm bug

```gotemplate
resources:
  {{- toYaml .Values.app.resources | nindent 12 }}
```

`toYaml` serialises a values map back to YAML. `nindent 12` prepends a newline
and indents **every** line by 12 spaces. Using `indent` instead leaves the first
line glued to the `resources:` colon and produces invalid YAML. After a `key:`,
you want `nindent`.

The `{{-` prefix trims preceding whitespace **including the newline**, which is
what stops template control lines from leaving blank lines everywhere.

### `tpl` — rendering a value as a template

`.Files.Get` reads a file as a plain string. `tpl` compiles that string as a
template and renders it against a context. Together they let the Prometheus
config live in `files/prometheus.yml` as a **complete, valid, syntax-highlighted
Prometheus config** rather than being buried inside YAML indentation:

```gotemplate
data:
  prometheus.yml: |
    {{- tpl (.Files.Get "files/prometheus.yml") . | nindent 4 }}
```

### `.Files.Glob` — a directory becomes a ConfigMap

```gotemplate
{{- range $path, $_ := .Files.Glob "files/alert-rules/*.yaml" }}
{{ base $path }}: |
  {{- tpl ($.Files.Get $path) $ | nindent 4 }}
{{- end }}
```

Drop a new `.yaml` into `files/alert-rules/` and it becomes a new ConfigMap key
with **no template change at all**. `base` strips the directory, so the key
matches the `rule_files: /etc/prometheus/rules/*.yaml` glob — each ConfigMap key
is projected into the container as a file of that name.

### Escaping: when Prometheus and Helm both want `{{ }}`

Prometheus alert annotations use `{{ $labels.pod }}`. So does Helm. Since the
rule files are rendered through `tpl`, an unescaped placeholder makes Helm look
for a variable named `$labels` and fail with *"undefined variable"*.

The standard escape is a backtick-quoted raw string inside a Helm action:

```
summary: "Pod {{`{{ $labels.pod }}`}} is crash looping"
```

Helm evaluates the outer action, the backticks make the inner text literal, and
Prometheus receives exactly `{{ $labels.pod }}`. `kube-prometheus-stack` escapes
its rules the same way.

> **This applies to comments too.** `tpl` renders the *whole file*, so a Helm
> action inside a `#` line is still evaluated. A YAML comment is not a template
> comment. Only `{{/* … */}}` is.

The alternative — loading the rules with `.Files.Glob(...).AsConfig`, which does
no templating and needs no escaping — was rejected because then the namespace
and app name could not follow the values, and renaming a namespace would
silently break every Kubernetes-level alert.

### The config checksum pattern

This is the fix for the "config changed but nothing restarted" bug:

```gotemplate
annotations:
  checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
```

`include` renders that template file to a string; `sha256sum` hashes it. The
hash lands in the **pod template**, so any ConfigMap change alters the pod spec
and the Deployment rolls. Without it, a `helm upgrade` that only edits config
reports success while every pod keeps the old values.

> **A template cannot include itself.** Alertmanager's ConfigMap lives in its own
> file (`alertmanager/configmap.yaml`) precisely so the Deployment can hash it
> without infinite recursion.

### Values merge semantics

Precedence, lowest to highest:

```
subchart values.yaml  →  parent values.yaml  →  -f file1  →  -f file2  →  --set
```

- **Maps merge** key by key.
- **Lists are replaced wholesale.** There is no "append one item to a list".
- A key that matches a subchart name becomes that subchart's `.Values` root, so
  `application.app.replicaCount` in the parent lands as `.Values.app.replicaCount`
  inside `charts/application`.
- `--set` uses dots for nesting and needs escaping for literal dots:
  `--set 'ingress.annotations.nginx\.ingress\.kubernetes\.io/rewrite-target=/'`.
  Use `--set-string` when a value would otherwise be coerced to a number
  (image tags like `1.10` are the classic victim — YAML reads that as a float).

`values-prod.yaml` contains **only differences** from `values.yaml`. Copying the
whole base file and editing it is the usual mistake: the copy stops tracking new
defaults the moment the chart is upgraded.

### `values.schema.json`

If present, Helm validates merged values against it **before rendering
anything**, on install, upgrade, lint and template. `--set app.replicaCount=two`
becomes an immediate readable error instead of an obscure API-server rejection.

Each chart owns its own schema, and a subchart's schema still applies when the
parent overrides its values — the parent cannot bypass it.

Ours are deliberately shallow — types and hard limits only, with
`additionalProperties` left open. Restating every default in the schema just
creates a second values file to keep in sync.

### Hooks

A hook is an ordinary manifest with a `helm.sh/hook` annotation. Helm pulls it
*out* of the normal release and applies it at a specific lifecycle point.

```yaml
annotations:
  helm.sh/hook: test
  helm.sh/hook-weight: "1"                                    # ordering, lowest first, a STRING
  helm.sh/hook-delete-policy: before-hook-creation,hook-succeeded
```

Hook points: `pre-install`, `post-install`, `pre-upgrade`, `post-upgrade`,
`pre-delete`, `post-delete`, `pre-rollback`, `post-rollback`, `test`.

Delete policies:
- `before-hook-creation` — delete the previous run first, so a re-run does not
  fail with "already exists"
- `hook-succeeded` — tidy up after a pass, but **leave a failed pod behind** so
  `kubectl logs` can explain the failure
- `hook-failed` — the opposite

A test pod that exits `0` passes.

**Our tests check something real**, not just "the pod is running":

- `application` — hits `/readyz`, which the app implements by pinging Redis. One
  HTTP call proves Service DNS resolves, the selector matches real pods, the app
  booted, the ConfigMap-derived `REDIS_HOST` is correct, and Redis is serving.
  Then it exercises the write path with `POST /shorten`.
- `monitoring` — asserts Prometheus loaded the alert rules and has live scrape
  targets. A typo in a relabel rule makes Prometheus start up perfectly happily
  and scrape *nothing*; no readiness probe catches that.
- `aiagent` — checks `/healthz` only. It deliberately does **not** send a fake
  alert: that would email on-call and burn LLM tokens on every `helm test`. A
  test with side effects outside the cluster is a test people stop running.

### Resource policy

```yaml
annotations:
  helm.sh/resource-policy: keep
```

Tells Helm to leave the object behind on uninstall. Used on the PVCs — a PVC
deleted by `helm uninstall` takes the data with it, and data loss should be an
explicit `kubectl delete pvc`, never a side effect. Optional on namespaces via
`namespaces.retain`.

The catch: a retained object blocks a later re-install with an ownership error.
See §13 for the adoption command.

### What we deliberately avoided

- **`lookup`** — queries the live cluster. It returns empty during
  `helm template` and `--dry-run`, so any template that branches on it renders
  differently than it applies. That is a debugging nightmare.
- **`.Capabilities.APIVersions.Has` gymnastics** — `kubeVersion` in `Chart.yaml`
  states the requirement once, clearly, instead of scattering compatibility
  branches through the templates.
- **A `library` chart for shared helpers** — it would remove some duplication
  between the three `_helpers.tpl` files, but each subchart would then need the
  library vendored into its own `charts/` before it could be installed alone.
  Independent installability was a requirement, so a little duplication won.

---

## 6. Every Helm concept used, with the file to read

| Concept | Where to read it |
|---|---|
| Umbrella chart, vendored subcharts | `Chart.yaml` |
| `condition`, `tags`, and their precedence | `Chart.yaml` dependencies |
| `global` values shared across subcharts | `values.yaml`, every `*.namespace` helper |
| `define` / `include` / name collisions | all three `_helpers.tpl` |
| Scoped context via `dict` | `charts/monitoring/templates/_helpers.tpl` |
| Template variables (`$roleName`) | `charts/aiagent/templates/rbac.yaml` |
| `coalesce`, `dig`, `default`, `required` | namespace and secret-name helpers |
| `tpl` — render a value as a template | `charts/monitoring/templates/prometheus/configmap.yaml` |
| `.Files.Get`, `.Files.Glob` | same file, plus `charts/monitoring/files/` |
| Escaping `{{ }}` for Prometheus | `charts/monitoring/files/alert-rules/app-alerts.yaml` |
| `toYaml \| nindent` (and why not `indent`) | every `resources:` block |
| Config checksums forcing a rollout | app / Prometheus / Alertmanager / agent Deployments |
| Hooks, weights, delete policies | `*/templates/tests/*` |
| `NOTES.txt`, `--render-subchart-notes` | every chart |
| `values.schema.json` | parent and `charts/application` |
| `helm.sh/resource-policy: keep` | PVCs; optional on namespaces |
| Conditional whole objects | `hpa.yaml`, `ingress.yaml`, `pdb.yaml`, `networkpolicy.yaml`, `secret.yaml` |
| `range` over a map | `templates/namespaces.yaml`, rules ConfigMap |
| `index` for dynamic key lookup | `templates/namespaces.yaml` |
| `with` for optional blocks + scope change | `storageClassName` in `redis.yaml` |
| Layered `-f` files, merge semantics | `values-prod.yaml` |

> **`NOTES.txt` gotcha:** by default Helm prints only the **parent** chart's
> notes. Add `--render-subchart-notes` to see the subcharts' notes too. That is
> why each subchart's notes are written for standalone installs.

---

## 7. Template function cheat sheet

Only the ones actually used in this chart.

| Function | Does | Example here |
|---|---|---|
| `default D V` | `V` unless empty, then `D` | `default "url-shortener" .Values.nameOverride` |
| `coalesce a b c` | first non-empty | namespace resolution |
| `dig k1 k2 D map` | walk nested map, `D` if the path is **missing** | `dig "namespaces" "application" "" .Values.global` |
| `required "msg" V` | abort with a readable error if empty | `aiagent.secretName` |
| `index M K` | dynamic key lookup | `index $.Values $key` |
| `dict "k" v` | build a map inline | scoped label helpers |
| `printf` | format a string | every `*.fullname` helper |
| `trunc 63` / `trimSuffix "-"` | fit RFC 1123 limits; names may not end in `-` | every name helper |
| `replace "+" "_"` | `+` is illegal in a label value | `helm.sh/chart` label |
| `quote` | wrap in `"` | every ConfigMap value |
| `toYaml` | map → YAML string | `resources:` blocks |
| `nindent N` | newline + indent every line | after every `key:` |
| `sha256sum` | hash a string | `checksum/config` |
| `tpl S ctx` | render a string as a template | Prometheus config |
| `base P` | filename from a path | rules ConfigMap keys |
| `gt` / `and` / `not` / `ne` / `eq` | comparisons — **functions, not operators** | `gt (int .Values.app.replicaCount) 1` |

Go templates have no infix operators. You write `gt a b`, and nested calls need
parentheses: `(int .Values.x)`.

**`default` vs `dig` — a real bug we hit.** `dig` only falls back when the key
is **missing**. A key that exists and is empty (`fullnameOverride: ""`, which is
exactly what the subchart defaults contain) returns the empty string. The parent
`NOTES.txt` needed both:

```gotemplate
{{- $appName := dig "fullnameOverride" "" .Values.application | default "url-shortener" }}
```

---

## 8. Versioning — which number to change when

This is the part people get wrong most often, because there are **four**
independent version numbers and they answer different questions.

| Number | Lives in | Answers | Who changes it |
|---|---|---|---|
| `version` | `Chart.yaml` | "which version of the **packaging**?" | you, on every chart change |
| `appVersion` | `Chart.yaml` | "which version of the **software**?" | you, when the image changes |
| image `tag` | `values.yaml` / `--set` | "which **bytes actually run**?" | CI, on every deploy |
| release **revision** | Helm, automatic | "which **deployment** of this release?" | Helm, on every upgrade |

Only the **image tag** changes what runs. `version` and `appVersion` are
metadata; `appVersion` becomes the `app.kubernetes.io/version` label and shows
in `helm list`.

### `version` — SemVer, and Helm enforces it

`MAJOR.MINOR.PATCH`. The question it answers is *"what does someone upgrading
need to know?"*

**PATCH (1.0.0 → 1.0.1)** — nothing user-visible changes.
Comment fixes, a typo in `NOTES.txt`, an internal refactor of a helper, a bug fix
that does not change any value's name or meaning.

**MINOR (1.0.0 → 1.1.0)** — backwards-compatible addition.
A new value with a safe default, a new optional resource behind `enabled: false`,
a new alert rule, a bumped image default. Existing values files keep working
untouched.

**MAJOR (1.0.0 → 2.0.0)** — someone's values file or their cluster breaks.
- Renamed or removed a value (`app.replicas` → `app.replicaCount`)
- Changed the shape of a value (a string became a map)
- Changed `selectorLabels`, which are **immutable** on a Deployment — the
  upgrade will fail with *"field is immutable"* and needs a delete/reinstall
- Raised `kubeVersion`
- Changed a Service name that other systems resolve

Bump `version` on **every** change you commit. Helm refuses to upgrade to the
same chart version with different content in some workflows, and more
importantly `helm history` becomes meaningless if the version never moves.

### `appVersion` — track the application

Bump when the shipped software changes, not when the templates do. It is
free-form (`"1.4.2"`, `"2026-08-06"`, a git SHA) and does not have to be SemVer.

In this repo the parent's `appVersion` is the platform version;
`charts/application` uses the app's version and `charts/monitoring` uses the
Prometheus version, since that is the software each one actually ships.

### Subchart versions

A subchart's `version` and the parent's `dependencies[].version` must satisfy
each other. When you change a subchart you bump **three** things:

```
charts/monitoring/Chart.yaml       version: 1.0.0 → 1.1.0
helm/Chart.yaml  dependencies[]    version: "1.0.0" → "1.1.0"
helm/Chart.yaml                    version: 1.0.0 → 1.1.0
```

Miss the middle one and Helm errors with *"chart requires monitoring version
1.0.0 but 1.1.0 is present"*.

### The image tag — the only one that changes what runs

**Never deploy `latest`.** The default is `latest` only because the existing CI
publishes it. Three concrete reasons:

1. Two pods of the same Deployment can silently run **different code** — one
   pulled before the push, one after.
2. `helm rollback` becomes a lie: the manifest rolls back, the tag still
   resolves to the newest image.
3. It forces `imagePullPolicy: Always`, so every pod restart depends on the
   registry being reachable.

Wire the tag from CI instead:

```bash
helm upgrade --install aiops ./helm -n aiops-platform \
  --set application.app.image.tag="$GIT_SHA" \
  --set aiagent.image.tag="$GIT_SHA" \
  --atomic --timeout 10m
```

With immutable tags you can also drop to `imagePullPolicy: IfNotPresent`, which
`values-prod.yaml` does.

### Release revision — what rollback uses

Helm increments a revision on every `install`/`upgrade`/`rollback`. This is
separate from the chart version and you never set it.

```bash
helm history aiops -n aiops-platform
# REVISION  CHART                  APP VERSION  STATUS      DESCRIPTION
# 1         aiops-platform-1.0.0   1.0.0        superseded  Install complete
# 2         aiops-platform-1.1.0   1.0.1        deployed    Upgrade complete

helm rollback aiops 1 -n aiops-platform
```

Rollback restores that revision's rendered manifests **and** its values — which
is why it only works properly with immutable image tags.

### Decision table

| What changed | `version` | `appVersion` | Image tag | How you deploy |
|---|---|---|---|---|
| App source code | PATCH | new app version | `$GIT_SHA` | `--set …image.tag=$GIT_SHA` |
| Comment / docs only | PATCH | — | — | `helm upgrade` |
| New value, safe default | MINOR | — | — | `helm upgrade` |
| New optional resource, off by default | MINOR | — | — | `helm upgrade` |
| New alert rule | MINOR | — | — | `helm upgrade` (checksum restarts Prometheus) |
| Renamed / removed a value | MAJOR | — | — | update values files first |
| Changed `selectorLabels` | MAJOR | — | — | `helm uninstall` + install; upgrade **cannot** work |
| Raised `kubeVersion` | MAJOR | — | — | upgrade the cluster first |
| Subchart changed | bump sub + dep + parent | — | — | `helm upgrade` |

---

## 9. How to use it day to day

### Install

```bash
helm upgrade --install aiops ./helm -n aiops-platform --create-namespace
```

> **Install into its own control namespace.** Helm stores its release Secret in
> the namespace you pass to `-n`, so that namespace must already exist. If you
> point `-n` at `url-shortener` *and* the chart declares a `url-shortener`
> Namespace, the install fails with *"cannot be imported into the current
> release"*. `templates/namespaces.yaml` skips `.Release.Namespace` defensively,
> but a dedicated control namespace keeps all three workload namespaces
> Helm-managed, which is what you want.

Then create the agent's credentials — the chart deliberately does not own them
(see §11) — and roll the agent:

```bash
kubectl create secret generic incident-agent-secrets -n ai-agent \
  --from-literal=LLM_API_KEY='<your-llm-token>' \
  --from-literal=SMTP_PASSWORD=''

kubectl rollout restart deploy/incident-agent -n ai-agent
```

`helm upgrade --install` (rather than `helm install`) is the idiomatic form: it
installs if absent, upgrades if present, so the same command works in CI on the
first run and the hundredth.

### Production

```bash
helm upgrade --install aiops ./helm -n aiops-platform --create-namespace \
  -f ./helm/values-prod.yaml \
  --set application.app.image.tag="$GIT_SHA" \
  --set aiagent.image.tag="$GIT_SHA" \
  --atomic --timeout 10m
```

`--atomic` rolls the entire release back if anything fails to become ready, so
you never sit half-upgraded. It implies `--wait`, so give it a real `--timeout`.

### Individual subcharts

```bash
helm install app   ./helm/charts/application -n url-shortener --create-namespace
helm install mon   ./helm/charts/monitoring  -n monitoring    --create-namespace
helm install agent ./helm/charts/aiagent     -n ai-agent      --create-namespace
```

### Turning components off

```bash
helm upgrade aiops ./helm -n aiops-platform --set aiagent.enabled=false
```

Remember the tags precedence rule from §4 — use the `enabled` flags.

### Verify before you apply

```bash
helm lint ./helm --strict                 # schema + template syntax; --strict fails on warnings
helm template aiops ./helm -n aiops-platform          # render locally, read the YAML
helm template aiops ./helm | kubectl apply --dry-run=server -f -   # API server validates fields
helm diff upgrade aiops ./helm -n aiops-platform      # needs the helm-diff plugin
```

`helm template` catches template bugs. `--dry-run=server` catches *Kubernetes*
bugs — misspelled fields, bad API versions, admission-webhook rejections — that
`helm lint` cannot see. Run both.

Shortcuts are in `helm/Makefile`:

```bash
make -C helm lint
make -C helm validate
make -C helm install
make -C helm test
```

### After deploying

```bash
helm test aiops -n aiops-platform --logs
helm status aiops -n aiops-platform
helm get manifest aiops -n aiops-platform   # exactly what is in the cluster
helm get values aiops -n aiops-platform     # what you supplied
helm history aiops -n aiops-platform
```

`helm get manifest` is the single most useful debugging command: it shows the
final YAML as applied, so you can stop guessing what the templates produced.

### Demo incident

```bash
kubectl scale deploy/url-shortener-redis -n url-shortener --replicas=0
# redis_up hits 0 → RedisDown fires after 1m → Alertmanager → agent → RCA email
kubectl scale deploy/url-shortener-redis -n url-shortener --replicas=1
```

### Uninstall

```bash
helm uninstall aiops -n aiops-platform
```

This deletes the namespaces and everything in them — **including the
out-of-band agent Secret**. Set `namespaces.retain=true` (as `values-prod.yaml`
does) to keep them.

---

## 10. Our cluster — how the pieces find each other

### Namespaces

| Namespace | Chart | Contents |
|---|---|---|
| `aiops-platform` | — | Helm's release Secret only |
| `url-shortener` | `application` | FastAPI app ×2, Redis, ConfigMap |
| `monitoring` | `monitoring` | Prometheus, Alertmanager, kube-state-metrics |
| `ai-agent` | `aiagent` | incident-agent, read-only ClusterRole |

Namespaces are an isolation and naming boundary — **not** a security boundary on
their own. Cross-namespace traffic is allowed by default; that is what the
optional NetworkPolicies address.

### Service DNS — names, never IPs

Every Service is reachable at `<name>.<namespace>.svc.cluster.local`. Pods get
random IPs and are disposable; Services are stable.

| From → To | Address |
|---|---|
| app → Redis | `url-shortener-redis` (same namespace) |
| Prometheus → kube-state-metrics | `kube-state-metrics.monitoring.svc.cluster.local:8080` |
| Prometheus → Alertmanager | `alertmanager.monitoring.svc.cluster.local:9093` |
| Alertmanager → agent | `incident-agent.ai-agent.svc.cluster.local:8080/alert` |
| agent → Prometheus | `prometheus.monitoring.svc.cluster.local:9090` |

The chart uses the **fully qualified** form rather than the short name, because
short names rely on the pod's DNS search-domain list, which differs between
distributions and silently breaks cross-namespace lookups.

**Why the object names are stable and not `<release>-<chart>`.** Most public
charts prefix names with the release. These do not, because those DNS names are
a *published contract between the charts*: Alertmanager's webhook URL, the
agent's Prometheus URL, and the app's `REDIS_HOST` all resolve them.
Release-prefixing would make cross-chart wiring depend on what you typed after
`helm install`. `fullnameOverride` is still available as an escape hatch.

The cost — you cannot install two copies into one namespace — is the right
trade-off for a platform component. The **cluster-scoped RBAC names *are*
namespace-prefixed**, because those genuinely do collide across installs, and an
unprefixed ClusterRole would either fail the second install or silently rebind
the first one's permissions.

### Ports — three numbers people confuse

- **containerPort** — where the process listens (app 8000, Redis 6379,
  Prometheus 9090, Alertmanager 9093, agent 8080, KSM 8080)
- **Service `port`** — what the Service exposes (the app Service uses 80)
- **`targetPort`** — which container port it forwards to, referenced **by name**
  (`http`) so changing the container port cannot desynchronise them

### Discovery and alerting flow

1. App pods carry `prometheus.io/scrape/port/path` annotations. That is the
   *entire* integration with the monitoring chart.
2. Prometheus's `kubernetes_sd_configs: role: pod` job lists every pod, and
   `relabel_configs` **keeps** only the annotated ones, rewrites the scrape
   address from pod IP + annotated port, and copies `namespace`, `pod` and `app`
   onto every sample.
3. Prometheus evaluates alert rules every 15s. A rule goes
   `Inactive → Pending → Firing`, only firing once its `for:` duration elapses.
4. **Prometheus pushes** the fired alert to Alertmanager. Alertmanager never
   queries Prometheus — a very common misconception. It only groups,
   deduplicates, silences and routes.
5. Alertmanager POSTs to the agent's webhook.
6. The agent acknowledges immediately, then in a background task gathers
   read-only evidence, asks the LLM, and emails the RCA.

### Authentication vs authorization

- **Authentication** = *who am I*: the pod's mounted ServiceAccount token, which
  `collector.py` picks up via `load_incluster_config()`.
- **Authorization** = *what may I do*: RBAC — ServiceAccount (identity) +
  ClusterRole (permissions) + ClusterRoleBinding (the link). A role with no
  binding does nothing.

The agent feeds pod logs — attacker-controllable text — into an LLM, so prompt
injection is not hypothetical. The defence is not that the model will refuse;
the defence is that the credential the process holds has `get`/`list` and
nothing else. Two omissions are load-bearing: **no `secrets`** (it cannot read
other workloads' credentials or leak them into a prompt) and **no
`create`/`update`/`delete`/`exec`**.

Verify it holds — both must print `no`:

```bash
kubectl auth can-i delete pods --as=system:serviceaccount:ai-agent:incident-agent -A
kubectl auth can-i get secrets --as=system:serviceaccount:ai-agent:incident-agent -A
```

---

## 11. Improvements made over the raw manifests

### Two real bugs found in the originals

**Metric cardinality doubled on every deploy.** The Prometheus config used a
blanket relabel:

```yaml
- action: labelmap
  regex: __meta_kubernetes_pod_label_(.+)
```

That copies **every** pod label onto **every** series — including
`pod-template-hash`, which changes on each rollout. Every deploy orphaned the
old series and grew the TSDB. Replaced with explicit copies of the labels we
actually query, including one that maps `app.kubernetes.io/name` → `app` so the
alert rules stay readable as `app="url-shortener"`.

**Config changes never reached the pods.** Nothing forced a restart when a
ConfigMap changed, so `kubectl apply` reported success while Prometheus kept
running its old scrape config. Fixed with `checksum/config` annotations on all
four Deployments.

### Reliability

| Change | Why |
|---|---|
| `startupProbe` on the app | Slow starts no longer force a long `initialDelaySeconds` on liveness, so real hangs are still caught in ~30s |
| `maxUnavailable: 0`, `maxSurge: 1` | Genuinely zero-downtime rollouts — a new pod must pass readiness before an old one goes |
| PodDisruptionBudget | Node drains and cluster upgrades cannot take the service to zero |
| `topologySpreadConstraints` (`ScheduleAnyway`) | Replicas spread across nodes, but still schedule on a one-node laptop cluster |
| `Recreate` strategy on Redis-with-PVC, Prometheus, Alertmanager | A ReadWriteOnce volume cannot attach to old and new pods at once — a rolling update would deadlock |
| `terminationGracePeriodSeconds: 120` on the agent | A ~90s LLM call is no longer SIGKILLed mid-analysis during a rollout |
| `--cluster.listen-address=` on Alertmanager | Stops single-replica gossip errors and the startup settle delay |
| `--save ""` on Redis without a PVC | Stops endless snapshot-write failures against a read-only filesystem |
| `revisionHistoryLimit: 3` | The default of 10 is etcd clutter |

**Liveness vs readiness** was already right in the original and is preserved:
`/healthz` never touches Redis, `/readyz` does. A Redis outage must make pods
**unready** (stop traffic), not **unhealthy** (a restart loop that fixes nothing
and destroys the logs you need). The agent's liveness probe likewise does *not*
check the LLM proxy — probing a third-party dependency from a liveness probe
converts their outage into your crash loop.

### Security

| Change | Why |
|---|---|
| `runAsNonRoot`, numeric `runAsUser`, `runAsGroup`, `fsGroup` | See the note below |
| `readOnlyRootFilesystem: true` + a `/tmp` emptyDir | Nothing can be written into the container image at runtime |
| `capabilities.drop: [ALL]`, `allowPrivilegeEscalation: false` | Least privilege |
| `seccompProfile: RuntimeDefault` | Blocks the syscalls containers never need |
| Pod Security Admission labels on namespaces | Enforced at `baseline`, audited and warned at `restricted` — the standard safe rollout path. Everything already complies, so `values-prod.yaml` raises enforcement to `restricted` |
| `automountServiceAccountToken: false` on app and Redis | Neither calls the Kubernetes API; the token was a real cluster credential sitting inside a web server that parses untrusted URLs |
| Namespace-prefixed ClusterRole names | Unprefixed cluster-scoped names collide the moment the chart is installed twice |
| Optional NetworkPolicies | Default-deny plus explicit allows |

> **The numeric UID detail.** Both Dockerfiles end with `USER app` / `USER
> agent`, created via `useradd --system` — so the image records a user **name**,
> not a UID. kubelet cannot verify a name against `runAsNonRoot: true` and
> refuses to start the container with *"image has non-numeric user"*. Setting
> `runAsUser: 1000` explicitly is the fix; these processes only read
> world-readable files, so the UID is free to choose.
>
> `fsGroup` matters for Prometheus in a way it does not for the app: Prometheus
> **writes** its TSDB to a mounted volume, and without `fsGroup` that volume is
> root-owned and Prometheus crashes with *permission denied* on `/prometheus`.

**NetworkPolicies are ingress-only, on purpose.** Adding `Egress` to
`policyTypes` immediately breaks DNS, because CoreDNS lives in `kube-system` and
every lookup would be dropped. Egress lockdown needs its own explicit DNS allow
rule plus CIDR blocks for the external LLM proxy and SMTP relay — that belongs
in a cluster-wide policy, and half-done egress rules are how people take down
their own clusters.

They are also **off by default**, because on a CNI that does not enforce policy
(plain kindnet, minikube's default) the API server accepts them and silently
ignores them — and a silently-ignored security control is worse than an absent
one, so it should be an explicit decision.

### Secrets

The chart manages the **shape** of the agent's Secret — its name, and which keys
the Deployment expects — but not its **contents**. `secret.create` defaults to
`false`.

A Kubernetes Secret is base64, not encryption; that part is unavoidable. What
*is* avoidable is the extra copies Helm would create. Putting the LLM token in a
values file copies it into git, into `helm get values`, and into Helm's release
Secret — where it survives every rollback and shows up in `helm history`. Three
unrotated copies.

This is also exactly the seam that External Secrets Operator or the Vault agent
injector slot into: they populate a Secret with the same name, and nothing else
in the chart changes.

The cost is honest and documented: Helm cannot hash a Secret it does not own, so
rotating the key needs an explicit `kubectl rollout restart`.

`secret.create=true` exists for laptop clusters, uses `stringData` (plaintext in,
API server encodes — far easier to read in a diff than pre-`b64enc`'d `data`),
and prints a warning in `NOTES.txt`.

### Resources

Requests and limits are set everywhere, but with a deliberate asymmetry:
**memory is limited, CPU is not.**

CPU is compressible — a limit only adds throttling latency once the request has
already guaranteed a share, and CPU throttling is a common source of mysterious
p99 latency. Memory is incompressible: without a limit, one leak can evict its
neighbours. So: CPU requests for scheduling fairness, memory limits for blast
radius.

### Design decisions worth defending

**Redis stays a Deployment.** The reflex answer is "Redis is stateful, use a
StatefulSet". A StatefulSet buys stable per-replica identity, ordered rollout and
per-replica volumes. This is a single-replica, cache-like store with no
clustering and no peer discovery, so it uses none of them — and the ordering
semantics would make recovery slower. Switch when it becomes Sentinel/Cluster
with replicas that find each other by ordinal, or better, use managed Redis.

**Hand-rolled monitoring, not `kube-prometheus-stack`.** In production you would
depend on the community chart and get the Prometheus Operator, CRDs
(`ServiceMonitor`, `PrometheusRule`) and Grafana. Here the mechanics — service
discovery, relabelling, rule evaluation, alert routing — *are* the subject, and
the operator hides them behind CRDs. It is also ~200 MB lighter, needs no CRDs,
and has no upgrade coupling.

**No over-parameterisation.** Probe paths and thresholds, container ports,
scrape intervals, alert thresholds and the `prometheus.io/*` annotations are
**not** values. They describe how this specific software behaves. Every knob you
expose is a line of documentation, a schema entry and a test case forever —
and a knob nobody turns is pure cost.

The best example of templating done right is `REDIS_HOST`: derived from the same
helper that names the Redis Service, so the two cannot drift. **Templating earns
its keep by removing duplicated facts, not by adding knobs.**

---

## 12. Mistakes made while building this

Kept because they are the kind of thing that costs an afternoon.

**A template that included itself.** Alertmanager's Deployment originally hashed
the file that contained the hash — infinite recursion. Split into
`alertmanager/configmap.yaml`. Rule: the checksum target must be a *different*
file.

**Helm actions inside YAML comments.** Several explanatory comments contained
literal `{{ }}`, which Helm evaluates even inside `#` lines. `{{ }}` on its own
is a parse error and `{{ $labels.pod }}` is an undefined-variable error. Only
`{{/* … */}}` is a template comment.

**`dig` on a defined-but-empty key.** `dig "fullnameOverride" "url-shortener" …`
returned `""`, not the fallback, because the key *exists* in the subchart
defaults with an empty value. `dig` falls back on **missing**, not on **empty**.
Needed `| default` as well.

**Claiming `tags` worked when they did not.** The README initially documented
`--set tags.observability=false`. Because `monitoring.enabled` is defined in
values, the condition always resolves and overrides the tag, so that flag does
nothing. Fixed the docs rather than removing the feature — the precedence rule
is worth knowing.

---

## 13. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `cannot be imported into the current release` | The object already exists and is not owned by this release. Adopt it (below) or delete it |
| Agent pod `CreateContainerConfigError` | `incident-agent-secrets` does not exist yet. Create it, then `kubectl rollout restart` |
| `field is immutable` on upgrade | A label moved into `selectorLabels`. Deployment selectors cannot change — uninstall and reinstall |
| `container has runAsNonRoot and image has non-numeric user` | The image's `USER` is a name. Set a numeric `runAsUser` |
| Prometheus scrapes nothing | Missing `prometheus.io/scrape` annotations, or a relabel `keep` dropped them. Check `/api/v1/targets` |
| Alerts fire, nothing arrives | Webhook URL points at the wrong namespace: `helm get manifest aiops \| grep -A2 webhook_configs` |
| `error converting YAML to JSON: line N` | An `indent` that should be `nindent`, or a missing `{{-`. Run `helm template` and read line N of the output |
| `nil pointer evaluating interface {}.foo` | Walking a map that does not exist. Guard with `(… | default dict)` and `dig` |
| ConfigMap rejected: `cannot unmarshal number into string` | A numeric value in `data:` — add `| quote` |
| `helm upgrade` hangs | `--atomic` implies `--wait`; something never becomes ready. `kubectl get pods` in another terminal |

**Adopting an existing object into a release:**

```bash
kubectl annotate ns url-shortener \
  meta.helm.sh/release-name=aiops \
  meta.helm.sh/release-namespace=aiops-platform --overwrite
kubectl label ns url-shortener app.kubernetes.io/managed-by=Helm --overwrite
```

**When a rendered manifest is not what you expected**, always start here:

```bash
helm template aiops ./helm -n aiops-platform | less   # what Helm produces
helm get manifest aiops -n aiops-platform             # what is actually installed
```

---

## 14. Interview talking points

Short answers to the questions this project invites.

**Why an umbrella chart?** The three components are wired to each other across
namespaces. `global.namespaces` gives those references one source of truth.
Subcharts keep the boundaries so each is separately installable and reviewable.

**Why does the parent own namespaces?** A namespace outlives any component and is
shared. Two owners means the second install fails and uninstalling one deletes
the other's home. Helm's kind-based install ordering puts Namespace first, so no
hooks are needed.

**How is a subchart still independently installable?** It never declares a
Namespace, and it resolves its own via
`coalesce(global.namespaces.X, namespaceOverride, .Release.Namespace)`, with
`dig` guarding the case where `global` does not exist.

**Why aren't names release-prefixed?** They are a published contract between the
charts and with operators. Cluster-scoped RBAC names *are* prefixed, because
those actually collide.

**How do you avoid over-parameterising?** A value exists only if someone would
plausibly change it per environment. Behaviour — probe paths, ports, alert
thresholds — stays in the templates. Templating's job is removing duplicated
facts, not adding knobs.

**How does a config change reach a running pod?** It does not, by default. That
is why every config-consuming Deployment carries a `checksum/config` annotation
that changes the pod template and forces a rollout.

**How do you handle secrets?** The chart owns the Secret's shape, not its
contents. Values-file secrets end up in git, `helm get values` and release
history. The named-Secret seam is where External Secrets or Vault plugs in.

**Which version do you bump?** `version` for the chart on every change (SemVer,
MAJOR when someone's values break), `appVersion` when the software changes, and
the **image tag** — always immutable, always from CI — for what actually runs.

**How do you validate before shipping?** `helm lint --strict` for schema and
syntax, `helm template | kubectl apply --dry-run=server` for API-server
validation, `helm diff upgrade` to see the change, `--atomic` so a failed
upgrade rolls itself back, then `helm test`.

**What would you do differently at real scale?** Depend on
`kube-prometheus-stack` instead of hand-rolling; run the agent outside the
cluster it watches (right now it shares fate with what it monitors); managed
Redis; a library chart for shared helpers once independent installability stops
being a requirement; and sign and publish chart packages to an OCI registry
instead of installing from a path.
